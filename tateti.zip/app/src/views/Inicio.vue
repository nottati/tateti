<template>
    <div>
    <div>
        <h1> Jugador 1: </h1>
        <input type="text" placeholder="Escriba su nombre" v-model="nombreJ1">
        <button class="button is-primary" @click="guardarNombre1"> Aceptar </button>
    </div>
    <div>
        <h1> Jugador 2: </h1>
        <input type="text" placeholder="Escriba su nombre" v-model="nombreJ2">
        <button class="button is-primary" @click="guardarNombre2"> Aceptar </button>
    </div>
    <div>
        <router-link :to="{ name: 'Tateti'}"> <button class="button is-medium is-success"> ¡Jugar! </button> </router-link>
        </div>
    </div>
</template>

<script>
import axios from 'axios'


export default {
    name: 'Inicio',
    data (){
        return{
            nombreJ1: '',
            nombreJ2: '',
            
        }
    },
    methods: {
        guardarNombre1 (){
            //tenemos que enviar el nombre al servidor para que lo guarde en la base
            //de datos.
            axios.post('http://localhost:4500', this.nombreJ1)
            .then(function(resultado){
                console.log('se guardó el nombre del juagdor 1', resultado)
            }).catch(function(error){
                console.error(error)
            })
            console.log('El  nombre del  jugador 1 es: ', this.nombreJ1)
            },
          guardarNombre2 (){
            //tenemos que enviar el nombre al servidor para que lo guarde en la base
            //de datos.
            console.log('El  nombre del  jugador 2 es: ', this.nombreJ2)
            },  
    }
}
</script>

<style>

</style>
