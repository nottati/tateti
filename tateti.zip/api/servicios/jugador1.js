var router = require('express').Router();
var Jugador1 = require('../modelos/jugador1');

router.get('/tateti', function(req, res){
    Jugador1.find({}).then(function(jugador1){
        res.send(jugador1);
    })
});

router.post('/', function(req, res){
    var Jugador = new Jugador1(req.body);
    console.log(Jugador);
    Jugador.save().then(function(jugador1){
        res.send(jugador1);
    }).catch(function(error){
        res.status(400).send(error);
    })
})

module.exports = router;