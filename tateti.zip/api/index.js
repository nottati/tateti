var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('./db/conexion').mongoose;
const morgan = require('morgan');
var cors = require('cors');

const servicioJugador1 = require('./servicios/jugador1');

var app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(morgan('combined'));

app.use(servicioJugador1);

app.listen(4500, function(){
    console.log('la app está corriendo');
})